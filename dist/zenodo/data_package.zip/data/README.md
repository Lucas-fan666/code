# Processed network data

Layout after unpacking into the repository root:

    data/processed/<stem>.edges            edge list, one edge per line, "u v"
    data/processed/<stem>.temporal.tsv     "u v timestamp" (three temporal networks)
    data/processed/main_subset/*.edges     the eight SNAP networks of the study

The edge lists are the exact files the experiment reads. `data/manifests/` holds
the original SNAP URL, the SHA-256 of the downloaded archive and the parsed node
and edge counts for each network, so a reader can verify that these are the
published networks and not a modification of them.

File stem to the name used in the paper:

    email-Eu-core        EmailEuCore        ca-GrQc    CaGrQc
    facebook_combined    FacebookEgo        ca-HepTh   CaHepTh
    email-Enron          EmailEnron         ca-CondMat CaCondMat
    wiki-Vote            WikiVote           p2p-Gnutella08 P2PGnutella08

Which networks belong to which part of the paper:

* Main results (Sections 5 and 6, Tables 1-21): 23 networks = the eight SNAP
  networks in `main_subset/` (also in `processed/`), two classical graphs
  (Karate, Les Miserables) and thirteen synthetic networks.
* Appendix A (24-network comparison, Tables 22-23): the same 23 plus
  Florentine (twenty edges).
* Held-out replication (Section 5.15): ca-HepPh and ca-AstroPh, listed in
  `held_out/`; they are never mixed into the main benchmark.
* Further empirical networks: as-Caida, Oregon1, p2p-Gnutella24 and
  p2p-Gnutella31 are in `processed/` for readers who want to extend the
  benchmark; they are not part of any reported result.
* Temporal experiment (Section 5.16): email-Eu-core-temporal,
  soc-sign-bitcoinotc, soc-sign-bitcoinalpha.

Not stored here, because the released code builds them deterministically:
the two classical graphs (NetworkX) and the thirteen synthetic networks
(`src/benchmarks.py`, parameters in `config/final_config.json`). The random
seed of every experiment is recorded in its result file.
